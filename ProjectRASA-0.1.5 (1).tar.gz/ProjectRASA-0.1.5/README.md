# ProjectRASA
Game project for CSCE 3444  
Project Rasa is a top-down Metroidvania in the vein of classic Zelda titles. Taking place in a steampunk city long lost to its own ambitions, our protagonist travels to the ruins to end a long-lasting curse and give the city its final rites. The main focus of the gameplay in this game is to translate the freedom of problem solving and traversal found in modern Zelda titles into the format of a top-down action game.
